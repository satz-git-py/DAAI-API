# -*- coding: utf-8 -*-
"""
Created on Mon Aug 30 17:50:06 2021

@author: S@tZ
"""

from apps import create_app

if __name__ == "__main__":
    create_app().run(debug=True)
